//
//  CustomMemeCell.swift
//  MemeMe
//
//  Created by Andrew Ardire on 7/26/17.
//  Copyright © 2017 Andrew F Ardire. All rights reserved.
//

import UIKit

class CustomMemeCell: UICollectionViewCell {
    
    // TODO: Two Labels And An Image 
    @IBOutlet weak var memeImageView: UIImageView!
    
}
